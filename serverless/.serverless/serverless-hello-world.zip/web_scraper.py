#!/usr/bin/env python3.7

import webbrowser

webbrowser.open('https://www.webscraper.io/test-sites/e-commerce/allinone')
