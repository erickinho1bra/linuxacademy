#!/usr/bin/env python3.6

import sys

print(f"Positional arguments {sys.argv[1:]}")
print(f"First argument: {sys.argv[1]}")
