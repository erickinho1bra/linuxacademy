def lambda_handler(event, context):

    import _cffi_backend
    import paramiko
    # import os
    # import fnmatch
    # import shutil
    # import boto3
    #from botocore.exceptions import NoCredentialsError

    ACCESS_KEY = 'AKIATKRAE24FJ36T5SB3'
    SECRET_KEY = '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'

    ftpHost = "tp.s6.exacttarget.com"
    ftpUsername = "6419404"
    myPassword = "nelle@20170828"

    s3Bucket = "ellentube-prod-sfmc-data"

    name = "Erick"
    response = "My name is " + name
    return {
        "Sentence": response
    }